#library(testthat)
#library(choroplethr)

#test_package("choroplethr")
