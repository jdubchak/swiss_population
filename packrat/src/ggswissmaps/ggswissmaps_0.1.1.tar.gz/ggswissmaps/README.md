# ggswissmaps

[![Travis-CI Build Status](https://travis-ci.org/gibonet/ggswissmaps.svg?branch=master)](https://travis-ci.org/gibonet/ggswissmaps)


R package


# Installation

The package can be installed from CRAN:

```
install.packages("ggswissmaps")
```

or from github:

```
# install.packages("devtools")
devtools::install_github("gibonet/ggswissmaps")
```
