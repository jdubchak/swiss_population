#' This is data included in sf
#'
#' @name bgMap
#' @aliases g
#' @docType data
#' @keywords data
NULL
