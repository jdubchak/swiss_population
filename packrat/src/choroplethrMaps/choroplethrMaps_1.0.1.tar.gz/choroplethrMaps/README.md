`choroplethrMaps` is an R package that contains 3 maps used by the `choroplethr` package. The maps are:
  * US States
  * US Counties
  * Countries of the world.
 
## Documentation

Documentation for choroplethrMaps, including a free course, can be found [here](http://www.arilamstein.com/open-source).

